package com.swadhin.broadbandwifi;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private LinearLayout deviceList;
    private TextView status, count;
    private Button scanButton;
    private final ExecutorService executor = Executors.newFixedThreadPool(32);
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private TextView text(String value, float size) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(16, 10, 16, 10); return t;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18, 18, 18, 8);
        root.setBackgroundColor(Color.WHITE);

        TextView title = text("Swadhin Broadband WiFi", 24);
        title.setGravity(Gravity.CENTER); title.setTextColor(Color.rgb(21,101,192)); title.setTypeface(null, 1);
        root.addView(title);

        TextView subtitle = text("Simple local Wi-Fi device scanner", 14);
        subtitle.setGravity(Gravity.CENTER); root.addView(subtitle);

        count = text("Devices found: 0", 18); count.setTypeface(null, 1); root.addView(count);
        status = text("Connect to Wi-Fi, then tap Scan", 14); root.addView(status);

        scanButton = new Button(this); scanButton.setText("SCAN WI-FI"); root.addView(scanButton);

        ScrollView scroll = new ScrollView(this);
        deviceList = new LinearLayout(this); deviceList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(deviceList); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        scanButton.setOnClickListener(v -> scanNetwork());
    }

    private String localIPv4() {
        try {
            Enumeration<NetworkInterface> all = NetworkInterface.getNetworkInterfaces();
            while (all.hasMoreElements()) {
                NetworkInterface ni = all.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                }
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void scanNetwork() {
        final String myIp = localIPv4();
        if (myIp == null) { status.setText("Please connect to Wi-Fi first."); return; }
        int dot = myIp.lastIndexOf('.');
        if (dot < 0) { status.setText("Could not read the Wi-Fi network."); return; }
        final String base = myIp.substring(0, dot + 1);

        scanButton.setEnabled(false); deviceList.removeAllViews(); count.setText("Devices found: 0");
        status.setText("Scanning local network…");

        executor.execute(() -> {
            List<String> found = Collections.synchronizedList(new ArrayList<>());
            CountDownLatch done = new CountDownLatch(254);
            for (int i = 1; i <= 254; i++) {
                final int host = i;
                executor.execute(() -> {
                    try {
                        String ip = base + host;
                        if (ip.equals(myIp) || InetAddress.getByName(ip).isReachable(500)) found.add(ip);
                    } catch (Exception ignored) {} finally { done.countDown(); }
                });
            }
            try { done.await(20, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
            found.sort(Comparator.comparingInt(MainActivity::lastOctet));
            main.post(() -> {
                scanButton.setEnabled(true); count.setText("Devices found: " + found.size());
                status.setText("Scan complete • Your phone: " + myIp);
                for (String ip : found) addDevice(ip, ip.equals(myIp));
            });
        });
    }

    private static int lastOctet(String ip) {
        try { return Integer.parseInt(ip.substring(ip.lastIndexOf('.') + 1)); } catch (Exception e) { return 999; }
    }

    private void addDevice(String ip, boolean thisPhone) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(14, 12, 14, 12); card.setBackgroundColor(Color.rgb(245,247,250));
        TextView name = text(thisPhone ? "📱  This phone" : "●  Device on Wi-Fi", 17);
        name.setTypeface(null, 1); card.addView(name);
        card.addView(text("IP address: " + ip, 14));
        try {
            String host = InetAddress.getByName(ip).getCanonicalHostName();
            if (!host.equals(ip)) card.addView(text("Name: " + host, 13));
        } catch (Exception ignored) {}
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 6, 0, 0);
        deviceList.addView(card, lp);
    }

    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
