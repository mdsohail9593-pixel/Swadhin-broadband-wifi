# Swadhin Broadband WiFi

A small, read-only Android Wi-Fi/LAN device scanner.

## Build from only a phone
This project includes a GitHub Actions workflow, so you do not need Android Studio or a computer.

1. On your phone, create a new GitHub repository.
2. Upload the contents of this folder to the repository (the folder containing `app`, `build.gradle`, `settings.gradle`, and `.github`).
3. Open the repository's **Actions** tab.
4. Select **Build Swadhin Broadband WiFi APK**.
5. Tap **Run workflow** (or push to `main`, which starts the workflow automatically).
6. When the build finishes, open the workflow run and download the **Swadhin-Broadband-WiFi-debug** artifact.
7. Extract the artifact and install `app-debug.apk` on your Android phone.

## What the app does
- Finds reachable devices on the phone's local IPv4 /24 network.
- Shows the number of detected devices and their IP addresses.
- Tries to show a hostname when available.
- Does not contain router login, password changing, port forwarding, or configuration-changing functions.

## Important limitation
Android and some Wi-Fi networks can prevent discovery of every device. A scan result is therefore not guaranteed to equal the router's exact client list. The app intentionally does not request router credentials.
